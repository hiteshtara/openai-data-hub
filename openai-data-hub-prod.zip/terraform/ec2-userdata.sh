#!/bin/bash
echo 'prod startup'