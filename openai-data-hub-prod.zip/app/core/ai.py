import openai
from .config import OPENAI_API_KEY
openai.api_key=OPENAI_API_KEY